from django.shortcuts import render,redirect
from django.views import View
from .models import Student

# Create your views here.
class index(View):
    def get(self,request):
        return render(request,'home/index.html')
    def post(self,request):
        rn=request.POST['rn']
        name=request.POST['name']
        age=request.POST['age']
        data=Student(rn=rn,name=name,age=age)
        data.save()
        msg={'m':"Data Saved !"}
        return render(request,'home/index.html',msg)
    
class read(View):
    def get(self, request):
        d=Student.objects.all()
        return render(request, 'home/read.html', {'d':d})
    
class edit(View):
    def get(self, request):
        id=request.GET['q']
        st=Student.objects.get(id=id)
        return render(request, 'home/edit.html', {'st':st})
    def post(self, request):
        id=request.GET['q']
        st=Student.objects.get(id=id)
        st.rn=request.POST['rn']
        st.name=request.POST['name']
        st.age=request.POST['age']
        st.save()
        return redirect('read')
    
class delete(View):
    def get(self, request):
        id=request.GET['q']
        st=Student.objects.get(id=id)
        return render(request, 'home/delete.html', {'st':st})
    def post(self, request):
        id=request.GET['q']
        st=Student.objects.get(id=id)
        st.delete()
        return redirect('read')
    



    





