from django.urls import path 
from . import views 

urlpatterns=[
    path('',views.index.as_view(),name='index'),
    path('read',views.read.as_view(),name='read'),
    path('edit',views.edit.as_view(),name='edit'),
    path('delete',views.delete.as_view(),name='delete'),
]